﻿using System;

namespace ConsoleCalculator
{
    public class Calculator
    {
        public string DisplayText { get; private set; } = string.Empty;

        public void SendKeystroke(char keyChar)
        {
            // Add your logic here.
            throw new NotImplementedException();
        }
    }
}
