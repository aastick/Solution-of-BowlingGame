﻿using System;
using System.Collections.Generic;
using BowlingBallBusiness;
using BowlingBallBusiness.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        [TestMethod]
        public void Gutter_game_score_should_be_zero_test()
        {
            var mockIBo = new Mock<IBowlingBu>();
            var game = new Game(mockIBo.Object);
            Roll(game, 0, 20);
            GameModel gm = new GameModel();
            gm.CumulativeVal = 0;
            gm.FirstTry = 0;
            gm.SecondTry = 0;
            game.framelist.Add(gm);
            int index = game.framelist.Count - 1;
            Assert.AreEqual(game.framelist[index].CumulativeVal.Value, game.GetScore());
        }

        private void Roll(Game game, int pins, int times)
        {
            for (int i = 0; i < times; i++)
            {
                game.Roll(pins);
            }
        }
    }
}
