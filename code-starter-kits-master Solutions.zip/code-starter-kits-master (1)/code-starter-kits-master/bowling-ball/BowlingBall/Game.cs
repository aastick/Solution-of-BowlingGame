﻿using BowlingBallBusiness;
using BowlingBallBusiness.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Game
    {
        private IBowlingBu _bowlingBu;

      public  List<GameModel> framelist = new List<GameModel>();
        public Game(IBowlingBu bowlingBu)
        {

            _bowlingBu = bowlingBu;
        }
        public void Roll(int pins)
        {
            // Add your logic here. Add classes as needed.
            _bowlingBu.ProcessGame(pins,framelist);
        }

        public int GetScore()
        {
            int ind = framelist.Count - 1;
            // Returns the final score of the game.
            return framelist[0].CumulativeVal.Value;
        }
    }
}
