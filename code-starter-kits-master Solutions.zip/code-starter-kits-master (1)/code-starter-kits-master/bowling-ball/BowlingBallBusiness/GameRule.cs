﻿using BowlingBallBusiness.Interface;
using System;
using System.Collections.Generic;

namespace BowlingBallBusiness
{
    public class GameRule:IBowlingBu
    {
        
        public void ProcessGame(int pin, List<GameModel> framelist)
        {
            int index = 0;
            bool isFirstTry = false;
            if (framelist.Count > 0)
            {
                index = framelist.Count - 1;
                if (framelist[index].SecondTry == null || framelist[index].FirstTry==10 || framelist[index].SecondTry>0 || framelist[index].SecondTry == -1)
                {
                    isFirstTry = true;
                }
            }
            if(isFirstTry || framelist.Count == 0)
            {
                GameModel gmod = new GameModel();
                framelist.Add(gmod);
                isFirstTry = true;
            }
            if (index > 2 && framelist[index - 1].IsStrike && framelist[index - 2].IsStrike && isFirstTry)
            {
                framelist[index].CumulativeVal += pin;
                framelist[index].IsSpare = false;
            }

            index = framelist.Count - 1;
            if (index > 0)
            {
                framelist[index].CumulativeVal = framelist[index - 1].CumulativeVal;
            }
            if (framelist.Count > 0)
            {
              
               
               
                if (pin < 10)
                {
                    if (isFirstTry)
                    {
                        framelist[index].FirstTry = pin;
                        framelist[index].SecondTry = 0;
                    }
                    else
                    {
                        framelist[index].SecondTry = pin;
                        framelist[index].CumulativeVal += framelist[index].FirstTry + framelist[index].SecondTry;
                        if (framelist[index].FirstTry + framelist[index].SecondTry == 10)
                        {
                            framelist[index].IsSpare = true;
                           
                        }
                        CalculateBonusForPrevious(framelist, index);
                    }

                    if (pin == 0 && !isFirstTry)
                        framelist[index].SecondTry = -1;

                }
                else if (pin == 10)
                {
                    if (isFirstTry)
                    {
                        framelist[index].FirstTry = pin;
                        framelist[index].IsStrike = true;
                        //framelist[index].SecondTry = 0;
                        framelist[index].CumulativeVal = framelist[index].CumulativeVal==null?pin: framelist[index].CumulativeVal+pin;
                     
                    }
                    else
                    {
                        framelist[index].SecondTry = 10;
                        framelist[index].CumulativeVal += pin;

                    }
                    if (index > 0)
                    CalculateBonusForPrevious(framelist, index);
                }


            }

           
        }

        private void CalculateBonusForPrevious(List<GameModel> framelist,int index)
        {
            if (framelist[index - 1].IsSpare)
            {
                framelist[index].CumulativeVal += framelist[index].FirstTry;
            }
            else if (framelist[index - 1].IsStrike)
                framelist[index].CumulativeVal += framelist[index].FirstTry + (framelist[index].SecondTry??0); 

           
        }
    }
    
}
