﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBallBusiness
{
   public  class GameModel
    {
        public int? FirstTry { get; set; }
        public int? SecondTry { get; set; }

        public bool IsStrike { get; set; }

        public bool IsSpare { get; set; }

        public int? CumulativeVal { get; set; }
    }
}
