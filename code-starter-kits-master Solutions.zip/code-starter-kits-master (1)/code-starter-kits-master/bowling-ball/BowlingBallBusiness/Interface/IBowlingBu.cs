﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BowlingBallBusiness.Interface
{
   public interface IBowlingBu
    {
         void ProcessGame(int pin, List<GameModel> framelist);
        
    }
}
